package com;

public class  Travels<Drivers> {

	public boolean  isCarDriver(Driver[] drivers){
		for (Driver d : drivers) {
			if (d.getCategory().equalsIgnoreCase("car")) {
			return true;
			}
			}
			return false;
 }
	public String retrivebyDriverId(Driver[] drivers,int driverId)
	{
		for (Driver d1 : drivers) 
		{
			if (d1.getDriverId() == driverId)
			{
			return "Driver name is "+ d1.getDriverName()+" Belonging to the category "+d1.getCategory()+" traveled "+d1.getTotalDistance()+" KM so far.";
			}
		}
		return "car not found";
		}
	
	public  int  retriveCountOfDriver(Drivers[] driver,String category) 
	{ 
		int count=0;
		for(Drivers d:driver)
		{
		 if(((Driver) d).getCategory().equalsIgnoreCase(category))
		 {
			count++; 
		 }
			
		}
		return count;
		
		
	}
	public Driver[] retriveDriver(Driver[] drivers, String category) {


		int count = 0;


		for (Driver d : drivers) {
		if (d.getCategory().equalsIgnoreCase(category)) {
		count++;
		}
		}


		Driver[] result = new Driver[count];
		int index = 0;


		for (Driver d : drivers) {
		if (d.getCategory().equalsIgnoreCase(category)) {
		result[index++] = d;
		}
		}
		return result;
		}
	

		public Driver RetriveMaximumDistanceTravelledDriver(Driver[] drivers) {


		if (drivers == null || drivers.length == 0) {
		return null;
		}


		Driver maxDriver = drivers[0];


		for (Driver d : drivers) {
		if (d.getTotalDistance() > maxDriver.getTotalDistance()) {
		maxDriver = d;
		}
		}
		return maxDriver;
		}

}
